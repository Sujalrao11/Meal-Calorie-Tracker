# MealMate Calorie Tracker

MealMate is a JavaFX desktop application for tracking meals and calories. Users can enter the date, meal type, food item, quantity, and calories. The app displays all saved meals in a table, calculates total calories, calculates today's calories, and saves data to a local CSV file.

## Features
- JavaFX GUI with text fields, date picker, combo box, table view, and buttons
- Add and delete meal entries
- Input validation and exception handling
- File persistence using `data/meals.csv`
- Object-oriented structure with model, service, repository, and UI classes

## Requirements
- Java 17 or newer
- Maven

## How to Run
```bash
mvn clean javafx:run
```

## Project Structure
```text
src/main/java/com/mealmate/MainApp.java
src/main/java/com/mealmate/model/MealEntry.java
src/main/java/com/mealmate/model/MealType.java
src/main/java/com/mealmate/service/MealRepository.java
src/main/java/com/mealmate/service/FileMealRepository.java
src/main/java/com/mealmate/service/MealTracker.java
src/main/java/com/mealmate/ui/MealTableView.java
```

## Data File
The app creates this file automatically after the first saved meal:
```text
data/meals.csv
```

## GitHub Submission
Create a GitHub repository, push this project, and paste your repository URL into the report.
