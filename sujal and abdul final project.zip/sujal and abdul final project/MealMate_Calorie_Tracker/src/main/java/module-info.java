module com.mealmate {
    requires javafx.controls;
    exports com.mealmate;
    exports com.mealmate.model;
    exports com.mealmate.service;
    exports com.mealmate.ui;
}
