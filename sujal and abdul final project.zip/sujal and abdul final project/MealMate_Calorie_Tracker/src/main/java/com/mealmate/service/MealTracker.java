package com.mealmate.service;

import com.mealmate.model.MealEntry;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MealTracker {
    private final MealRepository repository;
    private final List<MealEntry> meals;

    public MealTracker(MealRepository repository) throws IOException {
        this.repository = repository;
        this.meals = new ArrayList<>(repository.loadMeals());
    }

    public List<MealEntry> getMeals() {
        return Collections.unmodifiableList(meals);
    }

    public void addMeal(MealEntry meal) throws IOException {
        meals.add(meal);
        save();
    }

    public void deleteMeal(MealEntry meal) throws IOException {
        meals.remove(meal);
        save();
    }

    public int getTotalCalories() {
        return meals.stream().mapToInt(MealEntry::getCalories).sum();
    }

    public int getCaloriesForDate(LocalDate date) {
        return meals.stream()
                .filter(meal -> meal.getDate().equals(date))
                .mapToInt(MealEntry::getCalories)
                .sum();
    }

    private void save() throws IOException {
        repository.saveMeals(meals);
    }
}
