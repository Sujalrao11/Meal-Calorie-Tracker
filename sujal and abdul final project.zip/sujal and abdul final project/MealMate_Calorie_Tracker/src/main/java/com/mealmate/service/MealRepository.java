package com.mealmate.service;

import com.mealmate.model.MealEntry;

import java.io.IOException;
import java.util.List;

public interface MealRepository {
    List<MealEntry> loadMeals() throws IOException;
    void saveMeals(List<MealEntry> meals) throws IOException;
}
