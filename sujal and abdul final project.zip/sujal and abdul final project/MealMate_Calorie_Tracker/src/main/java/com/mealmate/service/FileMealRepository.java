package com.mealmate.service;

import com.mealmate.model.MealEntry;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FileMealRepository implements MealRepository {
    private final Path filePath;

    public FileMealRepository(Path filePath) {
        this.filePath = filePath;
    }

    @Override
    public List<MealEntry> loadMeals() throws IOException {
        List<MealEntry> meals = new ArrayList<>();
        if (!Files.exists(filePath)) {
            return meals;
        }
        for (String line : Files.readAllLines(filePath)) {
            if (!line.trim().isEmpty()) {
                meals.add(MealEntry.fromCsvLine(line));
            }
        }
        return meals;
    }

    @Override
    public void saveMeals(List<MealEntry> meals) throws IOException {
        Path parent = filePath.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }
        List<String> lines = meals.stream().map(MealEntry::toCsvLine).toList();
        Files.write(filePath, lines);
    }
}
