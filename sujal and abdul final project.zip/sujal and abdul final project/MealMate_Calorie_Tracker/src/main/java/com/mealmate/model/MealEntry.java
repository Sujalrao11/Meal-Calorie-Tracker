package com.mealmate.model;

import java.time.LocalDate;
import java.util.Objects;

public class MealEntry {
    private LocalDate date;
    private MealType mealType;
    private String foodName;
    private String quantity;
    private int calories;

    public MealEntry(LocalDate date, MealType mealType, String foodName, String quantity, int calories) {
        setDate(date);
        setMealType(mealType);
        setFoodName(foodName);
        setQuantity(quantity);
        setCalories(calories);
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        if (date == null) {
            throw new IllegalArgumentException("Date cannot be empty.");
        }
        this.date = date;
    }

    public MealType getMealType() {
        return mealType;
    }

    public void setMealType(MealType mealType) {
        if (mealType == null) {
            throw new IllegalArgumentException("Meal type cannot be empty.");
        }
        this.mealType = mealType;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        if (foodName == null || foodName.trim().isEmpty()) {
            throw new IllegalArgumentException("Food name cannot be empty.");
        }
        this.foodName = foodName.trim();
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        if (quantity == null || quantity.trim().isEmpty()) {
            throw new IllegalArgumentException("Quantity cannot be empty.");
        }
        this.quantity = quantity.trim();
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        if (calories < 0) {
            throw new IllegalArgumentException("Calories cannot be negative.");
        }
        this.calories = calories;
    }

    public String toCsvLine() {
        return escape(date.toString()) + "," + escape(mealType.name()) + "," + escape(foodName) + "," + escape(quantity) + "," + calories;
    }

    public static MealEntry fromCsvLine(String line) {
        String[] parts = line.split(",", -1);
        if (parts.length != 5) {
            throw new IllegalArgumentException("Invalid saved meal line: " + line);
        }
        return new MealEntry(
                LocalDate.parse(unescape(parts[0])),
                MealType.valueOf(unescape(parts[1])),
                unescape(parts[2]),
                unescape(parts[3]),
                Integer.parseInt(parts[4])
        );
    }

    private static String escape(String value) {
        return value.replace("%", "%25").replace(",", "%2C").replace("\n", "%0A");
    }

    private static String unescape(String value) {
        return value.replace("%0A", "\n").replace("%2C", ",").replace("%25", "%");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MealEntry that)) return false;
        return calories == that.calories && Objects.equals(date, that.date)
                && mealType == that.mealType && Objects.equals(foodName, that.foodName)
                && Objects.equals(quantity, that.quantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, mealType, foodName, quantity, calories);
    }
}
