package com.mealmate;

import com.mealmate.model.MealEntry;
import com.mealmate.model.MealType;
import com.mealmate.service.FileMealRepository;
import com.mealmate.service.MealTracker;
import com.mealmate.ui.MealTableView;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;

public class MainApp extends Application {

    private MealTracker tracker;
    private MealTableView table;
    private Label totalLabel;
    private Label todayLabel;

    @Override
    public void start(Stage stage) {

        try {
            tracker = new MealTracker(new FileMealRepository(Path.of("data", "meals.csv")));
        } catch (IOException e) {
            showAlert("Error", "Could not load saved data");
            return;
        }

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(15));

        // simple title (not fancy)
        Label title = new Label("Meal Calorie Tracker");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        Label subtitle = new Label("Track what you eat and calories per day");
        subtitle.setStyle("-fx-font-size: 12px;");

        VBox topBox = new VBox(5, title, subtitle);
        root.setTop(topBox);

        table = new MealTableView();
        table.setItems(FXCollections.observableArrayList(tracker.getMeals()));
        root.setCenter(table);

        GridPane form = new GridPane();
        form.setPadding(new Insets(10));
        form.setHgap(8);
        form.setVgap(8);

        DatePicker datePicker = new DatePicker(LocalDate.now());

        ComboBox<MealType> mealType =
                new ComboBox<>(FXCollections.observableArrayList(MealType.values()));
        mealType.setValue(MealType.BREAKFAST);

        TextField foodField = new TextField();
        foodField.setPromptText("ex: rice");

        TextField quantityField = new TextField();
        quantityField.setPromptText("ex: 1 plate");

        TextField caloriesField = new TextField();
        caloriesField.setPromptText("ex: 400");

        Button addBtn = new Button("Add");
        Button deleteBtn = new Button("Delete");
        Button clearBtn = new Button("Clear");

        // add meal
        addBtn.setOnAction(e -> {
            try {
                int cal = Integer.parseInt(caloriesField.getText());

                MealEntry entry = new MealEntry(
                        datePicker.getValue(),
                        mealType.getValue(),
                        foodField.getText(),
                        quantityField.getText(),
                        cal
                );

                tracker.addMeal(entry);
                table.getItems().setAll(tracker.getMeals());
                updateLabels();

                foodField.clear();
                quantityField.clear();
                caloriesField.clear();

            } catch (Exception ex) {
                showAlert("Error", "Enter correct calories");
            }
        });

        // delete
        deleteBtn.setOnAction(e -> {
            MealEntry selected = table.getSelectionModel().getSelectedItem();

            if (selected == null) {
                showAlert("Info", "Select something first");
                return;
            }

            try {
                tracker.deleteMeal(selected);
                table.getItems().setAll(tracker.getMeals());
                updateLabels();
            } catch (IOException ex) {
                showAlert("Error", "Could not delete");
            }
        });

        // clear form
        clearBtn.setOnAction(e -> {
            foodField.clear();
            quantityField.clear();
            caloriesField.clear();
        });

        form.add(new Label("Date"), 0, 0);
        form.add(datePicker, 1, 0);
        form.add(new Label("Meal"), 2, 0);
        form.add(mealType, 3, 0);

        form.add(new Label("Food"), 0, 1);
        form.add(foodField, 1, 1);
        form.add(new Label("Qty"), 2, 1);
        form.add(quantityField, 3, 1);

        form.add(new Label("Calories"), 0, 2);
        form.add(caloriesField, 1, 2);
        form.add(new HBox(8, addBtn, deleteBtn, clearBtn), 3, 2);

        totalLabel = new Label();
        todayLabel = new Label();
        updateLabels();

        HBox summary = new HBox(20, totalLabel, todayLabel);
        summary.setAlignment(Pos.CENTER_LEFT);

        VBox bottom = new VBox(10, form, summary);
        root.setBottom(bottom);

        Scene scene = new Scene(root, 750, 550);
        stage.setScene(scene);
        stage.setTitle("Meal Calorie Tracker");
        stage.show();
    }

    private void updateLabels() {
        totalLabel.setText("Total: " + tracker.getTotalCalories());
        todayLabel.setText("Today: " + tracker.getCaloriesForDate(LocalDate.now()));
    }

    private void showAlert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}