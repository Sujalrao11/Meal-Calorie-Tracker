package com.mealmate.model;

public enum MealType {
    BREAKFAST,
    LUNCH,
    SNACK,
    DINNER,
    OTHER
}
