package com.mealmate.ui;

import com.mealmate.model.MealEntry;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class MealTableView extends TableView<MealEntry> {
    public MealTableView() {
        TableColumn<MealEntry, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getDate().toString()));
        dateColumn.setPrefWidth(110);

        TableColumn<MealEntry, String> typeColumn = new TableColumn<>("Meal");
        typeColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getMealType().toString()));
        typeColumn.setPrefWidth(110);

        TableColumn<MealEntry, String> foodColumn = new TableColumn<>("Food Item");
        foodColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getFoodName()));
        foodColumn.setPrefWidth(190);

        TableColumn<MealEntry, String> quantityColumn = new TableColumn<>("Quantity");
        quantityColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getQuantity()));
        quantityColumn.setPrefWidth(140);

        TableColumn<MealEntry, String> caloriesColumn = new TableColumn<>("Calories");
        caloriesColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(String.valueOf(data.getValue().getCalories())));
        caloriesColumn.setPrefWidth(100);

        getColumns().addAll(dateColumn, typeColumn, foodColumn, quantityColumn, caloriesColumn);
        setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
    }
}
